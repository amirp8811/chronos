# RELEASE INVENTORY: CHRONOS v7.0 (Hardened Prototype)

This inventory lists all files in the repository and their status for a production release.

## 🟢 Production Code (Core Protocol & Runtimes)
These files constitute the core logic of the CHRONOS engine and will be shipped in release binaries/artifacts.

| Path | Category | Production Ready? |
| :--- | :--- | :--- |
| `crates/chronos-core/src/` | Cryptography & Logic | **YES** (Pending Audit) |
| `crates/chronos-sys-dataplane/src/` | Dataplane HAL | **YES** (Requires HW Validation) |
| `crates/chronosd/src/` | Relay Daemon | **YES** |
| `crates/chronos-wasm/src/` | Browser Runtime | **YES** |
| `crates/chronos-lite/src/` | Client Engine | **YES** |
| `configs/` | Node Configurations | **YES** |

## 🟡 Development & Build Tooling
These files are necessary for the build process and internal security audits, but are not "deployed" to end-users.

| Path | Category | Note |
| :--- | :--- | :--- |
| `Cargo.toml` / `Cargo.lock` | Build System | Root workspace definition. |
| `scripts/static_audit.py` | Security Tool | Internal linting tool for unsafe/panics. |
| `scripts/validation_pass.sh` | CI/CD | Automation for the 4-gate validation. |
| `bootstrap.sh` | Deployment | One-line installer for reference nodes. |

## 🔴 Non-Production / Reference Only
These files are used for testing, simulation, or documentation and **MUST NOT** be relied upon for production security claims.

| Path | Category | Reason |
| :--- | :--- | :--- |
| `tools/chronos-nettest/` | Simulation | Smoke-test harness (Multi-process loopback). |
| `fuzz/` | Testing | Continuous fuzzing targets. |
| `docs/` | Documentation | Reference material only. |
| `*.md` | Root Documentation | Status and architecture notes. |

---

## 🔒 Security Audit Trail (Internal)
Current SHA-256 hash of the core cryptographic engine for reference:
- `crates/chronos-core/src/lib.rs`: `[AUTO-GENERATE ON RELEASE]`
