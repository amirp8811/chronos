# CHRONOS Architecture & Implementation

This document provides a deep dive into the architectural vision, component structure, and implementation roadmap of CHRONOS v7.0.

---

## 1. Architectural Vision

CHRONOS is a production-grade, pure-software anonymous communication fabric engineered to solve the **Anonymity Trilemma** (Strong Anonymity, Low Latency, and Low Bandwidth Overhead).

Unlike legacy mixnets (Tor, I2P) that route traffic over single-path asynchronous TCP circuits, CHRONOS operates as a synchronous, **Time-Division Multiplexed (TDM)** and constant-rate paced multipath erasure network.

### Key Innovations:
- **Zero-Copy Data-Plane**: Utilizing `AF_XDP` and `io_uring` for sub-millisecond packet processing.
- **Multipath Erasure Coding**: (16,10) Reed-Solomon sharding to eliminate Head-of-Line (HoL) blocking.
- **Synchronous Mixing**: TDM-based packet flushing to defeat global passive adversaries (GPA).
- **Hardened Isolation**: Physical and logical decoupling between the cryptographic core (`no_std`) and platform-specific runtimes.

---

## 2. Component Deep-Dive

### `chronos-core` (The Sacred Core)
The mathematical and cryptographic backbone.
- **Target**: `#![no_std]` (alloc-only).
- **Current Status**: Refactored to gate `std` dependencies. True `no_std` compliance requires migrating the remaining platform-specific clocks to deterministic external ticks.
- **GF(2^8) Math**: Optimized Reed-Solomon erasure coding.
- **Sphinx-PQC**: Post-quantum onion routing (ML-KEM-768 + X25519).
- **Mix Policy**: Adaptive thresholding (AdaptiveMixConfig) to handle the latency-to-volume paradox.

### `chronos-sys-dataplane` (The Isolated HAL)
The only crate allowed to contain `unsafe` code for raw hardware interaction.
- **AF_XDP**: Zero-copy kernel bypass for 1 Tbps line rates.
- **io_uring**: High-performance asynchronous I/O batching.
- **Memory Management**: Lock-free UMEM descriptor pools with explicit `Acquire`/`Release` barriers for hardware-safe atomics.

### `chronosd` (The Relay Daemon)
High-availability relay for data-center deployments.
- **L3 Cache Locking**: Intel RDT/AMD resctrl for noisy-neighbor protection.
- **SIMD Sorting**: Constant-time bitonic networks for packet mixing.

### `chronos-dir` (The Consensus Mesh)
BFT-based decentralized directory authority.
- **BLS Quorums**: Regional super-quorums for <2.5s consensus finality.

### `chronos-wasm` & `chronos-lite` (Client Engines)
Cross-platform client runtimes for browsers and mobile/embedded devices.
- **WASM bindings**: Fortified with FFI panic barriers (`catch_unwind`) and stable C-ABI error codes.
- **Steganography**: Traffic waveform shaping (ARMA-GARCH GAN) to defeat Deep Packet Inspection.

---

## 3. Protocol Specifications (v7.0)

### **CHR7 (Secure Cell)**
Fixed 1,280-byte envelope.
- `CHR7` Magic | Version | Flags | Payload Len | Route Tag | IV | Ciphertext (944B) | MAC (16B).

### **CHS7 (Handshake)**
Hybrid PQC Key Exchange.
- Combines **ML-KEM-768** and **X25519** for transcript-bound session secrets.
- Includes memory-bounded PoW (Proof-of-Work) challenges for Anti-DoS.

### **CRP7 (Relay Packet)**
Multi-type wire format.
- `Hello` | `Shard` | `Ack` | `Error` | `Route` | `Data`.

### **RTE7 (Route Layer)**
Onion-wrapped routing commands.
- Per-hop ChaCha20-Poly1305, packet-id blinding, and single-use reply blocks.

---

## 4. Implementation Roadmap

### Tier 1: Logic & Correctness (Implemented)
- [x] Sphinx & Galois Math
- [x] Handshake & Route Layer State Machines
- [x] Basic Directory API & Consensus Prototype
- [x] FFI Panic Barriers & WASM Bindings

### Tier 2: Hardening & Performance (In Progress)
- [x] Isolated Dataplane HAL with memory ordering optimization.
- [x] Memory-Bounded PoW Validation (sliding-window epoch).
- [x] Macroscopic Statistical Leak Auditing (MI, KL Divergence).
- [ ] Full deterministic clock migration for 100% `no_std` compliance.

### Tier 3: Production Systems (Planned)
- [ ] Native `AF_XDP` driver-mode integration.
- [ ] Hardware-accelerated SIMD bitonic sorting.
- [ ] Regional BLS Quorum Mesh deployment.

---

## 5. Application Interfaces (Externalized)

Application runtimes are maintained in separate repositories to keep the core focused on systems engineering:
- **`chronos-web`**: Consumes the `@chronos/engine-wasm` npm package.
- **`chronos-mobile`**: Consumes native UniFFI / C-ABI artifacts.
