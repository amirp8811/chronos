# CHRONOS Security & Threat Model

This document outlines the security invariants, hardening measures, and threat model for CHRONOS.

---

## 1. Security Model

CHRONOS is designed to resist a **Global Passive Adversary (GPA)**—an entity capable of observing all internet backbone traffic.

### Invariants:
1. **Timing Indistinguishability**: Through TDM-based synchronous mixing and constant-rate pacing, ingress and egress packet intervals are statistically decoupled.
2. **Post-Quantum Resilience**: Every session combines **ML-KEM-768** with **X25519** to ensure secrecy against future quantum computers.
3. **Memory Isolation**: The data-plane is isolated into a dedicated HAL, and the core cryptographic logic is strictly `#![deny(unsafe_code)]`.
4. **Panic Safety**: All FFI boundaries (WASM/Mobile) use catch-all panic barriers to prevent memory corruption during unwinding.

---

## 2. Hardening Measures

### Anti-DoS (Memory-Bounded PoW)
To prevent memory exhaustion attacks, the PoW validator enforces:
- **Temporal Horizon**: Packets must have a timestamp within ±30s of the relay clock.
- **Epoch Purging**: Spent nonces are stored in a sliding-window cache that is cleared every 30s.

### Dataplane Integrity
- **Isolated HAL**: All `unsafe` code for AF_XDP and io_uring is pinned to `chronos-sys-dataplane`.
- **Memory Fences**: Explicit `Acquire`/`Release` memory barriers prevent CPU instruction reordering at the hardware ring boundary.

### Serialization Hardening
- **Stego-WS Parser**: Non-panicking, length-bounded decoder for steganographic WebSocket frames.
- **Differential Fuzzing**: Continuous fuzzing of ingress entry points using LibFuzzer.

---

## 3. Threat Model

### Supported Claims:
- **Resistance to Traffic Correlation**: Validated via macroscopic Mutual Information (MI) leak auditing.
- **Forward Secrecy**: Ephemeral keys are rotated every 60 seconds or 64k packets.
- **BFT Consensus Resilience**: Resists up to 1/3 malicious directory authorities.

### Non-Claims (Prototype Limitations):
- **Physical Side-Channels**: This software does not mitigate power or EM analysis on physical hardware.
- **OS-Level Compromise**: We assume the host kernel (or browser sandbox) is not compromised.
- **Global Active Attacks**: While we use PoW and signatures, aGPA capable of dropping 100% of global traffic can still disrupt the network.

---

## 4. Responsible Disclosure

If you find a security vulnerability, please contact the maintainers at `amirp8811@gmail.com`. We follow standard responsible disclosure practices.
