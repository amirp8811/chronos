# Contributing to CHRONOS

Thank you for your interest in making the world more private.

## Getting Started
1. Install Rust via `rustup`.
2. Fork the repo and run `cargo test`.
3. Read `ARCHITECTURE.md` to understand the TDM mixnet model.

## Good First Issues
- [ ] **Logging Improvement**: Standardize the `log!` macros in `chronos-lite`.
- [ ] **Unit Tests**: Add edge-case tests for the `gf28` Galois field math.
- [ ] **Documentation**: Help us improve the `mdBook` descriptions in `book/src`.
- [ ] **Metrics**: Add a new counter for "Handshake Failures" in `chronosd/src/metrics.rs`.

## Security
For vulnerabilities, please refer to `SECURITY.md`.
