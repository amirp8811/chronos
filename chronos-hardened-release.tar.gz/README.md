# CHRONOS: Low-Latency, Multipath Anonymous Communication Network

CHRONOS is a production-grade anonymous communication fabric designed for 1 Tbps performance and GPA (Global Passive Adversary) resistance. It utilizes synchronous Time-Division Multiplexing (TDM) and multipath erasure coding to solve the anonymity trilemma.

---

## 🛠 Project Status: Reference Prototype & Hardening

This repository is currently a **hardened reference prototype**. While core cryptographic and routing logic is implemented and validated, production deployment on bare-metal hardware requires site-specific NIC configuration.

**Current Focus**: Structural decoupling, memory safety isolation, and traffic analysis regression testing.

---

## 🚀 Quick Start

### Build & Test
```bash
# Build workspace
cargo build --workspace

# Run all unit and integration tests
cargo test --workspace

# Run strict security audit
python3 scripts/static_audit.py
```

### Simulation Harness (Smoke Test)
To run a local simulation of a 2-hop CHRONOS relay chain:
```bash
cargo run -p chronos-nettest
```

---

## 🏗 Repository Structure

- `crates/chronos-core`: The `no_std` cryptographic engine.
- `crates/chronos-sys-dataplane`: The isolated HAL for kernel-bypass networking.
- `crates/chronosd`: The high-performance relay daemon.
- `crates/chronos-dir`: Decentralized directory and consensus.
- `crates/chronos-lite`: Client runtime for mobile and embedded devices.
- `crates/chronos-wasm`: Browser runtime with FFI panic barriers.
- `fuzz/`: Dedicated targets for serialization and concurrency fuzzing.
- `scripts/`: Tooling for leak auditing and static security analysis.

---

## 📚 Documentation

- [Architecture & Protocols](ARCHITECTURE.md) - Deep dive into design and wire formats.
- [Security & Threat Model](SECURITY.md) - Analysis of anonymity claims and hardening.
- [Validation Architecture](VALIDATION.md) - How we prove correctness and security.
- [Contributing](CONTRIBUTING.md) - Guidelines for systems engineering contributions.

---

## ⚖️ License

CHRONOS is licensed under the **Apache License 2.0**.
