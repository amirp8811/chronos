# CHRONOS Anonymity & Differential Privacy Parameters

## Noise & Thresholds
- **Threshold (K)**: 25,000 packets.
- **Laplace Noise (epsilon)**: 0.1 per epoch.
- **Pacing**: 1ms ticks.

## Mixnet Strategy
CHRONOS uses a stop-and-go mixnet with cover traffic backfill. If K is not reached
within 50ms, the `mix_policy` initiates a cover-traffic injection or a reduced-threshold
flush to maintain a hard latency SLO while preserving epsilon-differential privacy.
