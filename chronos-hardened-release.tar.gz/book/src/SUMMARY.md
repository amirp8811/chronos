# Summary

- [Introduction](index.md)
- [Architecture & Protocols](architecture.md)
- [Security & Threat Model](security.md)
- [Validation Architecture](validation.md)
- [Anonymity Parameters](anonymity.md)
- [Implementation Status](status.md)
- [Roadmap](roadmap.md)
