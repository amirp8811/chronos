# CHRONOS Governance

CHRONOS currently operates under a **Benevolent Dictator for Life (BDFL)** model, led by Amir P (@amirp8811). 

## Decision Making
Major architectural changes are discussed via GitHub Issues and RFCs. Final approval rests with the BDFL.

## Roadmap
The roadmap is defined in `STATUS.md`.
