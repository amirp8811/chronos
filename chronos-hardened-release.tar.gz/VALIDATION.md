# CHRONOS Production Validation Architecture

The original test suite was a logic/regression suite, not a production systems validation suite. A green `chronos-nettest` run only proves that relay state machines can route valid packets in a sterile process topology. It does **not** prove 1 Tbps dataplane behavior, traffic-analysis resistance, or HAL memory safety.

This repository now separates validation into four gates.

---

## Gate 1: Parser & State-Machine Correctness
- **Functional Tests**: `cargo test --workspace --all-targets`
- **Logic Fuzzing**: `cargo fuzz run relay_packet`, `stego_ws_frame`, `dpf_query_request`.

**Purpose**: Reject malformed serialization, cryptographic envelope bugs, and browser/mobile ingress handling errors.

---

## Gate 2: Memory-Pool & Ring Lifecycle Validation
- **Concurrency Check**: `cargo test -p chronos-sys-dataplane` (includes `loom` tests for ring atomics).
- **Lifecycle Fuzzing**: `cargo fuzz run dataplane_lifecycle`.

**Purpose**: Model descriptor ownership transitions (`Free -> RxOwned -> TxOwned -> Free`). Rejects double-claims, double-frees, or invalid state transitions in the isolated HAL.

---

## Gate 3: Virtualized Hardware Topology & Burst-Loss Testing
- **Setup Script**: `sudo scripts/setup_virtual_topology.sh`

**Purpose**: Build a namespace/veth chain with XDP attachment and bursty impairment (`tc netem` using a Gilbert-Elliott model). This catches routing behavior under clustered loss and asymmetric jitter. 

*Note: `xdpgeneric` (veth fallback) is not a substitute for physical NIC native-driver zero-copy performance testing.*

---

## Gate 4: Macroscopic Traffic-Analysis Leak Auditing
- **Trace Collection**: `CHRONOS_NETTEST_MODE=leak-audit CHRONOS_NETTEST_PACKETS=100000 cargo run -p chronos-nettest`
- **Auditor**: `python3 scripts/traffic_leak_audit.py target/chronos-traces/nettest-paired-*.csv`

**Purpose**: Analyze macroscopic timing traces (N >= 100,000) using high-fidelity statistical metrics:
- **Pearson Inter-arrival Correlation**: Detects linear timing leaks.
- **Normalized Mutual Information (NMI)**: Detects non-linear statistical dependency between ingress and egress timing.
- **Kullback-Leibler (KL) Divergence**: Measures divergence from a uniform-shuffle baseline.
- **Egress Entropy**: Ensures pacing patterns do not reveal circuit-specific signatures.

---

## 🏗️ Physical Hardware Lab Gate
*Required before any production throughput or anonymity claims.*

Before finalizing a release, the following must be validated on physical server hardware (e.g., Intel E810 or Mellanox ConnectX):
1. **AF_XDP Native Driver Mode**: Validate 1 Tbps zero-copy path.
2. **RSS Queue Pinning**: Verify Toeplitz salt shuffle and cache-line affinity.
3. **Hardware Timestamps**: Perform leak auditing on sub-microsecond NIC timestamps.
4. **Sustained Load**: Run Gate 4 metrics under multi-gigabit line-rate saturation.
